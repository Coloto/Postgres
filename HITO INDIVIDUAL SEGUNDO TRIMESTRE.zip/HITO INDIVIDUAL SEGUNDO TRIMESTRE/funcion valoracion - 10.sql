CREATE DEFINER=`root`@`localhost` FUNCTION `valoracion`(s int, i int, u int) RETURNS varchar(30) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
	DECLARE resultado VARCHAR (30);
    IF S>=I AND S>=U THEN
		SET resultado='¡Ha gana sonido!';
	ELSEIF I>=S AND I>=U THEN
		SET resultado='¡Ha ganado imagen!';
	ELSEIF U>S AND U>I THEN
		SET resultado='¡Ha ganado usabilidad!';
	END IF;
RETURN resultado;
END