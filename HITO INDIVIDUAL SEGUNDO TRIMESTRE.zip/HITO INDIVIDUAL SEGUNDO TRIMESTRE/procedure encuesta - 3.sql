CREATE DEFINER=`root`@`localhost` PROCEDURE `crearEncuesta`()
BEGIN
-- Declarar variables --
	declare contador_provincias tinyint;
    declare contador_encuestas tinyint;
-- Eliminar tabla si existe --	
    DROP TABLE IF EXISTS ENCUESTA;
-- Crear tabla --
	CREATE TABLE ENCUESTA (
		IDENCUESTA INT AUTO_INCREMENT,
        PRIMARY KEY (IDENCUESTA),
		CODPROV CHAR(2),
		FOREIGN KEY (CODPROV) REFERENCES provincia (CODPROV),
		SONIDO INT NOT NULL,
		IMAGEN INT NOT NULL,
		USABILIDAD INT NOT NULL
	);
	SET contador_provincias=0;
-- Bucle contador de provincias --
    START TRANSACTION;
    WHILE contador_provincias<52 DO
		set contador_provincias=contador_provincias+1;
        set contador_encuestas=0;
-- Bucle contador de encuestas e inserción de datos en la tabla --
        WHILE contador_encuestas<10 DO
			set contador_encuestas=contador_encuestas+1;
			INSERT INTO ENCUESTA VALUES(NULL, LPAD(contador_provincias, 2, '0'),FLOOR(RAND()*11),FLOOR(RAND()*11),FLOOR(RAND()*11));
		END WHILE;
	END WHILE;
    COMMIT;
END