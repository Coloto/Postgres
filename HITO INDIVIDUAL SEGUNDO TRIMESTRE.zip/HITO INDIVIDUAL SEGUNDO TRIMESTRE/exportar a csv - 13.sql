SELECT * FROM encuesta INTO OUTFILE 'C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\encuesta.csv' FIELDS TERMINATED BY ';';


-- Lo de aqui abajo es para poder hacerlo. Rutas, permisos, etc.
SHOW VARIABLES LIKE 'secure_file_priv';
SHOW GRANTS FOR CURRENT_USER();
GRANT FILE ON *.* TO 'root'@'localhost';