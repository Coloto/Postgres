select encuestas.valoracion(5, 6, 9);



SELECT *,encuestas.valoracion(sonido, imagen, usabilidad) FROM encuesta;
SELECT IDENCUESTA, COUNT(idencuesta) as total, encuestas.valoracion(sonido, imagen, usabilidad) as ganador
from encuesta group by ganador;