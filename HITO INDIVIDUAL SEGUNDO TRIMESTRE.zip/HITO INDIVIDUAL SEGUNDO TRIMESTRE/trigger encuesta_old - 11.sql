DELIMITER &&
CREATE DEFINER=`root`@`localhost` TRIGGER `encuestaEliminada`
AFTER DELETE ON `encuesta` FOR EACH ROW
BEGIN
INSERT INTO encuesta_old VALUES (old.idencuesta,old.codprov,old.sonido,old.imagen,old.usabilidad);
END; &&
DELIMITER ;

select * from encuesta;

DELETE FROM encuesta where idencuesta='1';

select * from encuesta_old;